<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "trans_budget".
 *
 * @property int $id
 * @property int $user_id
 * @property int $scheme_id
 * @property int $component_id
 * @property int $financial_year_id
 * @property float $amount
 * @property string $remarks
 * @property string $uploaded_file
 * @property string $is_active
 * @property string $created_on
 * @property string $updated_on
 *
 * @property TransBudgetProposal[] $transBudgetProposals
 */
class Budget extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'trans_budget';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['user_id', 'scheme_id', 'component_id', 'financial_year_id', 'amount', 'remarks', 'uploaded_file'], 'required'],
            [['user_id', 'scheme_id', 'component_id', 'financial_year_id'], 'integer'],
            [['amount'], 'number'],
            [['is_active'], 'string'],
            [['created_on', 'updated_on'], 'safe'],
            [['remarks'], 'string', 'max' => 200],
            [['uploaded_file'], 'string', 'max' => 400],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User',
            'scheme_id' => 'Select Scheme',
            'component_id' => 'Select Component',
            'financial_year_id' => 'Select Financial Year',
            'amount' => 'Add Budget',
            'remarks' => 'Remarks',
            'uploaded_file' => 'File Upload',
            'is_active' => 'Is Active',
            'created_on' => 'Created On',
            'updated_on' => 'Updated On',
        ];
    }

    /**
     * Gets query for [[TransBudgetProposals]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransBudgetProposals()
    {
        return $this->hasMany(TransBudgetProposal::className(), ['budget_id' => 'id']);
    }
}
