<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use frontend\models\MstFinancialYear;
use frontend\models\MstScheme;
use frontend\models\MstComponent;
/* @var $this yii\web\View */
/* @var $model frontend\models\MstFinancialYear */
/* @var $form yii\widgets\ActiveForm */


//$FinancialYear = ArrayHelper::map(MstFinancialYear::find()->select(`id,concat(start_year,"-",end_year) as year`)->all(), 'id','year');

$FinancialYear = ArrayHelper::map(
  MstFinancialYear::find()->asArray()->all(),
  'id',
  function($model) {
      return $model['start_year'].'-'.$model['end_year'];
  }
);

$MstScheme = ArrayHelper::map(MstScheme::find('id', 'scheme')->all(),'id','scheme');
$component = ArrayHelper::map(MstComponent::find('id', 'component')->all(),'id','component');

?>

<div class="budget-form">

    <?php $form = ActiveForm::begin(); ?>

  <div class="row">
    <div class="col-md-6">
    <?= $form->field($model, 'financial_year_id')->dropDownList($FinancialYear) ?>
   
    </div>
    <div class="col-md-6">
    <?= $form->field($model, 'scheme_id')->dropDownList($MstScheme) ?>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
    <?= $form->field($model, 'component_id')->dropDownList($component ) ?>
    </div>
    <div class="col-md-6">
   
    <?= $form->field($model, 'amount')->textInput(['maxlength' => true]) ?>
    </div>
   </div>
   <div class="row">
   <div class="col-md-6">
   <?= $form->field($model, 'remarks')->textInput(['maxlength' => true]) ?>
   
   </div>
   <div class="col-md-6">
    <?= $form->field($model, 'uploaded_file')->textInput(['maxlength' => true]) ?>
    </div>
   </div>
  
 
    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
