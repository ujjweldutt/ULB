<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use frontend\models\MstFinancialYear;
use frontend\models\MstScheme;
use frontend\models\MstComponent;
use frontend\models\MstItems;
use frontend\models\MstUlb;
use frontend\models\MstWard;


/* @var $this yii\web\View */
/* @var $model frontend\models\Wms */
/* @var $form yii\widgets\ActiveForm */

$FinancialYear = ArrayHelper::map(
    MstFinancialYear::find()->asArray()->all(),
    'id',
    function($model) {
        return $model['start_year'].'-'.$model['end_year'];
    }
  );
  
  $MstScheme = ArrayHelper::map(MstScheme::find('id', 'scheme')->all(),'id','scheme');
  $component = ArrayHelper::map(MstComponent::find('id', 'component')->all(),'id','component');
  $MstItems = ArrayHelper::map(MstItems::find('id', 'item_name')->all(),'id','item_name');
  $MstUlb = ArrayHelper::map(MstUlb::find('id', 'name')->all(),'id','name');
  $MstWard = ArrayHelper::map(MstWard::find('id', 'ward_number')->all(),'id','ward_number');
?>

<div class="wms-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-4">
            <?= $form->field($model, 'ulb_id')->dropDownList( $MstUlb) ?>
        </div>
        <div class="col-md-4">
             <?= $form->field($model, 'ward_id')->dropDownList($MstWard) ?>
         </div>
         <div class="col-md-4">
             <?= $form->field($model, 'work_name')->textInput(['maxlength' => true]) ?>
         </div>
    </div>
    <div class="row">
        <div class="col-md-4">
        <?= $form->field($model, 'work_type')->textInput(['maxlength' => true]) ?>

        </div>
        <div class="col-md-4">
                <?= $form->field($model, 'work_sub_type')->textInput(['maxlength' => true]) ?>
         </div>

         <div class="col-md-4">
             <?= $form->field($model, 'work_scope')->textInput(['maxlength' => true]) ?>
         </div>
    </div>

    <div class="row">
        <div class="col-md-4">
        <?= $form->field($model, 'financial_year_id')->dropDownList($FinancialYear) ?>

        </div>
        <div class="col-md-4">
        <?= $form->field($model, 'scheme_id')->dropDownList($MstScheme) ?>
         </div>

         <div class="col-md-4">
         <?= $form->field($model, 'component_id')->dropDownList($component ) ?>
         </div>
    </div>

    <div class="row">
        <div class="col-md-4">
        
         <?= $form->field($model, 'announcement_type')->textInput(['maxlength' => true]) ?>

        </div>
        <div class="col-md-4">
             <?= $form->field($model, 'announcement_no')->textInput(['maxlength' => true]) ?>
         </div>

         <div class="col-md-4">
         <?= $form->field($model, 'announcement_date')->textInput() ?>
         </div>
    </div>

    <div class="row">
        <div class="col-md-4">
        
        <?= $form->field($model, 'site_plan_file')->fileInput(['maxlength' => true]) ?>

        </div>
        <div class="col-md-4">
        <?= $form->field($model, 'cross_section_file')->fileInput(['maxlength' => true]) ?>
         </div>

         <div class="col-md-4">
         <?= $form->field($model, 'l_section_file')->fileInput(['maxlength' => true]) ?>
         </div>
    </div>
    <div class="row">
        <div class="col-md-4">
        
        <?= $form->field($model, 'google_map_file')->fileInput(['maxlength' => true]) ?>

        </div>
        <div class="col-md-4">
        <?= $form->field($model, 'city_map_file')->fileInput(['maxlength' => true]) ?>
         </div>

         <div class="col-md-4">
         <?= $form->field($model, 'l_section_file')->fileInput(['maxlength' => true]) ?>
         </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
