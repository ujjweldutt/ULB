<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use frontend\models\MstFinancialYear;
use frontend\models\MstScheme;
use frontend\models\MstComponent;
/* @var $this yii\web\View */
/* @var $model frontend\models\BudgetProposal */
/* @var $form yii\widgets\ActiveForm */


$FinancialYear = ArrayHelper::map(
    MstFinancialYear::find()->asArray()->all(),
    'id',
    function($model) {
        return $model['start_year'].'-'.$model['end_year'];
    }
  );
  
  $MstScheme = ArrayHelper::map(MstScheme::find('id', 'scheme')->all(),'id','scheme');
  $component = ArrayHelper::map(MstComponent::find('id', 'component')->all(),'id','component');
  
?>

<div class="budget-proposal-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-md-4">
            <?= $form->field($budgetmodel, 'financial_year_id')->dropDownList($FinancialYear) ?>
        </div>
        <div class="col-md-4">
        <?= $form->field($budgetmodel, 'scheme_id')->dropDownList($MstScheme) ?>
        </div>
        <div class="col-md-4">
        <?= $form->field($budgetmodel, 'component_id')->dropDownList($component ) ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
         
         <?= $form->field($model, 'allocation_type')->dropDownList([ 'Auto' => 'Auto', 'On Demand' => 'On Demand', ], ['prompt' => 'Please Select']) ?>


        </div>
        <div class="col-md-6">
           
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
